import os
import tkinter as tk
from tkinter import filedialog, messagebox
import numpy as np
import pydicom
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure


class DicomMPRViewer:
    def __init__(self, root):
        self.root = root
        self.root.title("DICOM 3D MPR Viewer (Axial / Coronal / Sagittal)")
        self.root.geometry("1280x760")

        # ボリュームデータとメタデータ
        self.volume = None  # shape: (Z, Y, X)
        self.spacing = (1.0, 1.0, 1.0)  # (dz, dy, dx)
        self.z_idx = 0
        self.y_idx = 0
        self.x_idx = 0
        self.wl = 40.0
        self.ww = 400.0

        # 描画オブジェクト保持用
        self.im_ax = None
        self.im_cor = None
        self.im_sag = None
        self.lines = {}

        self._create_menu()
        self._create_widgets()

    #ファイルメニューの作成
    
    def _create_menu(self):
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="DICOMフォルダを開く...", command=self.load_dicom_folder)
        file_menu.add_separator()
        file_menu.add_command(label="終了", command=self.root.quit)
        menubar.add_cascade(label="ファイル", menu=file_menu)
        self.root.config(menu=menubar)


    #GUIレイアウトとスライダーの作成
   
    def _create_widgets(self):
        # 上部：画像表示エリア (Matplotlib)
        self.fig = Figure(figsize=(12, 5), dpi=100, facecolor="#222222")
        self.ax_axial = self.fig.add_subplot(131)
        self.ax_coronal = self.fig.add_subplot(132)
        self.ax_sagittal = self.fig.add_subplot(133)

        for ax, title in zip(
            [self.ax_axial, self.ax_coronal, self.ax_sagittal],
            ["Axial (Z)", "Coronal (Y)", "Sagittal (X)"]
        ):
            ax.set_title(title, color="white", fontsize=11)
            ax.set_facecolor("black")
            ax.tick_params(colors="gray", labelsize=8)

        self.fig.tight_layout(pad=2.0)

        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # 下部：コントロールパネル（スライダー群）
        ctrl_frame = tk.Frame(self.root, bg="#333333", padx=15, pady=10)
        ctrl_frame.pack(side=tk.BOTTOM, fill=tk.X)

        # 左側：スライス位置スライダー (Z, Y, X)
        slice_frame = tk.LabelFrame(ctrl_frame, text="スライス位置操作", fg="white", bg="#333333", padx=10, pady=5)
        slice_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)

        self.slider_z = self._make_slider(slice_frame, "Axial (Z):", 0, 100, 0, self.on_slice_change)
        self.slider_y = self._make_slider(slice_frame, "Coronal (Y):", 0, 100, 0, self.on_slice_change)
        self.slider_x = self._make_slider(slice_frame, "Sagittal (X):", 0, 100, 0, self.on_slice_change)

        # 右側：階調パラメータスライダー (WL, WW)
        win_frame = tk.LabelFrame(ctrl_frame, text="ウィンドウパラメータ (WL / WW)", fg="white", bg="#333333", padx=10, pady=5)
        win_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5)

        self.slider_wl = self._make_slider(win_frame, "WL (Center):", -1024, 3071, 40, self.on_window_change)
        self.slider_ww = self._make_slider(win_frame, "WW (Width):", 1, 4096, 400, self.on_window_change)

        # ステータスバー
        self.status_var = tk.StringVar(value="「ファイル」→「DICOMフォルダを開く...」からCTデータを選択してください。")
        status_bar = tk.Label(self.root, textvariable=self.status_var, bd=1, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def _make_slider(self, parent, label_text, from_, to, init_val, command):
        row = tk.Frame(parent, bg="#333333")
        row.pack(fill=tk.X, pady=2)
        lbl = tk.Label(row, text=label_text, width=13, anchor=tk.W, fg="white", bg="#333333")
        lbl.pack(side=tk.LEFT)
        slider = tk.Scale(
            row, from_=from_, to=to, orient=tk.HORIZONTAL,
            command=command, bg="#333333", fg="white", highlightthickness=0
        )
        slider.set(init_val)
        slider.pack(side=tk.RIGHT, fill=tk.X, expand=True)
        return slider

   
    #DICOMシリーズの読み込みと3Dボリューム構築
    
    def load_dicom_folder(self):
        folder_path = filedialog.askdirectory(title="DICOMファイルが含まれるフォルダを選択")
        if not folder_path:
            return

        slices = []
        for root_dir, _, files in os.walk(folder_path):
            for f in files:
                filepath = os.path.join(root_dir, f)
                try:
                    ds = pydicom.dcmread(filepath, force=True)
                    if hasattr(ds, "PixelData"):
                        slices.append(ds)
                except Exception:
                    continue

        if not slices:
            messagebox.showerror("エラー", "選択されたフォルダ内に有効なDICOM画像が見つかりませんでした。")
            return

        # スライス位置（InstanceNumber または ImagePositionPatient[2]）でソート
        try:
            slices.sort(key=lambda s: float(s.ImagePositionPatient[2]))
        except Exception:
            slices.sort(key=lambda s: int(getattr(s, "InstanceNumber", 0)))

        # HU値（RescaleSlope / RescaleIntercept適用）へ変換して3D配列化
        img_list = []
        for s in slices:
            arr = s.pixel_array.astype(np.float32)
            slope = float(getattr(s, "RescaleSlope", 1.0))
            intercept = float(getattr(s, "RescaleIntercept", 0.0))
            arr = arr * slope + intercept
            img_list.append(arr)

        self.volume = np.stack(img_list, axis=0)  # (Z, Y, X)
        nz, ny, nx = self.volume.shape

        # ボクセル間隔の取得（アスペクト比補正用）
        px_spacing = getattr(slices[0], "PixelSpacing", [1.0, 1.0])
        dy, dx = float(px_spacing[0]), float(px_spacing[1])
        if len(slices) > 1 and hasattr(slices[0], "ImagePositionPatient") and hasattr(slices[1], "ImagePositionPatient"):
            dz = abs(float(slices[1].ImagePositionPatient[2]) - float(slices[0].ImagePositionPatient[2]))
            if dz == 0:
                dz = float(getattr(slices[0], "SliceThickness", 1.0))
        else:
            dz = float(getattr(slices[0], "SliceThickness", 1.0))
        self.spacing = (dz, dy, dx)

        # スライダーの範囲更新（中央スライスを初期位置に設定）
        self.z_idx = nz // 2
        self.y_idx = ny // 2
        self.x_idx = nx // 2

        self.slider_z.config(from_=0, to=nz - 1)
        self.slider_z.set(self.z_idx)
        self.slider_y.config(from_=0, to=ny - 1)
        self.slider_y.set(self.y_idx)
        self.slider_x.config(from_=0, to=nx - 1)
        self.slider_x.set(self.x_idx)

        # 初期WL/WWの取得（タグがあれば反映、なければデフォルト）
        wc = getattr(slices[0], "WindowCenter", None)
        ww = getattr(slices[0], "WindowWidth", None)
        if wc is not None and ww is not None:
            self.wl = float(wc[0]) if isinstance(wc, pydicom.multival.MultiValue) else float(wc)
            self.ww = float(ww[0]) if isinstance(ww, pydicom.multival.MultiValue) else float(ww)
            self.slider_wl.set(int(self.wl))
            self.slider_ww.set(int(max(1, self.ww)))

        self._init_plots()
        self.status_var.set(
            f"読込完了: {os.path.basename(folder_path)} | サイズ: {nx}x{ny}x{nz} | "
            f"間隔(dx,dy,dz): ({dx:.2f}, {dy:.2f}, {dz:.2f}) mm"
        )

   
    #3断面表示とクロスヘア線の初期描画
  
    def _init_plots(self):
        if self.volume is None:
            return

        dz, dy, dx = self.spacing
        vmin = self.wl - self.ww / 2.0
        vmax = self.wl + self.ww / 2.0

        # 1. Axial (Z固定 -> Y x X)
        self.ax_axial.clear()
        self.ax_axial.set_title(f"Axial (Z = {self.z_idx})", color="white", fontsize=11)
        self.im_ax = self.ax_axial.imshow(
            self.volume[self.z_idx, :, :], cmap="gray", vmin=vmin, vmax=vmax, aspect=dy / dx
        )
        # Axial上の他2断面線（横線: Coronal Y, 縦線: Sagittal X）
        self.lines["ax_h"] = self.ax_axial.axhline(self.y_idx, color="lime", lw=1.0, linestyle="--")
        self.lines["ax_v"] = self.ax_axial.axvline(self.x_idx, color="cyan", lw=1.0, linestyle="--")

        # 2. Coronal (Y固定 -> Z x X) ※頭側を上にするため origin="lower"
        self.ax_coronal.clear()
        self.ax_coronal.set_title(f"Coronal (Y = {self.y_idx})", color="white", fontsize=11)
        self.im_cor = self.ax_coronal.imshow(
            self.volume[:, self.y_idx, :], cmap="gray", vmin=vmin, vmax=vmax, origin="lower", aspect=dz / dx
        )
        # Coronal上の他2断面線（横線: Axial Z, 縦線: Sagittal X）
        self.lines["cor_h"] = self.ax_coronal.axhline(self.z_idx, color="yellow", lw=1.0, linestyle="--")
        self.lines["cor_v"] = self.ax_coronal.axvline(self.x_idx, color="cyan", lw=1.0, linestyle="--")

        # 3. Sagittal (X固定 -> Z x Y) ※頭側を上にするため origin="lower"
        self.ax_sagittal.clear()
        self.ax_sagittal.set_title(f"Sagittal (X = {self.x_idx})", color="white", fontsize=11)
        self.im_sag = self.ax_sagittal.imshow(
            self.volume[:, :, self.x_idx], cmap="gray", vmin=vmin, vmax=vmax, origin="lower", aspect=dz / dy
        )
        # Sagittal上の他2断面線（横線: Axial Z, 縦線: Coronal Y）
        self.lines["sag_h"] = self.ax_sagittal.axhline(self.z_idx, color="yellow", lw=1.0, linestyle="--")
        self.lines["sag_v"] = self.ax_sagittal.axvline(self.y_idx, color="lime", lw=1.0, linestyle="--")

        self.canvas.draw_idle()


    #スライダー操作に伴う画像と線の連動更新
   
    def on_slice_change(self, _=None):
        if self.volume is None or self.im_ax is None:
            return

        self.z_idx = int(self.slider_z.get())
        self.y_idx = int(self.slider_y.get())
        self.x_idx = int(self.slider_x.get())

        # 画像データの更新
        self.im_ax.set_data(self.volume[self.z_idx, :, :])
        self.im_cor.set_data(self.volume[:, self.y_idx, :])
        self.im_sag.set_data(self.volume[:, :, self.x_idx])

        # タイトルのスライス番号更新
        self.ax_axial.set_title(f"Axial (Z = {self.z_idx})", color="white", fontsize=11)
        self.ax_coronal.set_title(f"Coronal (Y = {self.y_idx})", color="white", fontsize=11)
        self.ax_sagittal.set_title(f"Sagittal (X = {self.x_idx})", color="white", fontsize=11)

        #他の2つのスライス面を表す線の位置を連動更新
        self.lines["ax_h"].set_ydata([self.y_idx, self.y_idx])
        self.lines["ax_v"].set_xdata([self.x_idx, self.x_idx])

        self.lines["cor_h"].set_ydata([self.z_idx, self.z_idx])
        self.lines["cor_v"].set_xdata([self.x_idx, self.x_idx])

        self.lines["sag_h"].set_ydata([self.z_idx, self.z_idx])
        self.lines["sag_v"].set_xdata([self.y_idx, self.y_idx])

        self.canvas.draw_idle()

    def on_window_change(self, _=None):
        if self.volume is None or self.im_ax is None:
            return

        self.wl = float(self.slider_wl.get())
        self.ww = float(self.slider_ww.get())
        vmin = self.wl - self.ww / 2.0
        vmax = self.wl + self.ww / 2.0

        for im in (self.im_ax, self.im_cor, self.im_sag):
            im.set_clim(vmin=vmin, vmax=vmax)

        self.canvas.draw_idle()


if __name__ == "__main__":
    root = tk.Tk()
    app = DicomMPRViewer(root)
    root.mainloop()
